import java.io.Serializable;

public class NetworkInfo implements  Serializable
{
	private String pName;
	private String pAvatar;
	private String pMap;
	public NetworkInfo(String Name,String Map,String Avatar)
	{
		
	}

}
