//yeah, kinda small, but this is a really important part of the project
// its lets me pass events between my classes
public interface EventListener
{
	public void actionPerformed(Event e);
}
